package M9_U2_010;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

import Inter_Thread_Communication.ThreadB;

public class Main implements Runnable{
	
	public void run() {
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		thA thA = new thA();
		
		thA.start();
	}
	


}
