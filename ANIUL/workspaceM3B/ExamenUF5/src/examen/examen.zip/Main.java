package examen;

public class Main {
	public static void main(String[] args) {
		Llistat ll = new Llistat();
		
		ll.afegirParaula("Aniol");
		ll.afegirParaula("Antonio");
		ll.afegirParaula("albert");
		
		ll.mostrarEntrada('a');
	}
}
