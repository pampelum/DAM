package llista;

public class Node {
	Node next = null;
	String name = "";
	
	Node()
	{
		
	}
	
	Node(String n)
	{
		name = n;
	}
}
