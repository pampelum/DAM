package Pila_Gen;

public class Main {
	public static void main(String args[]){
		MyPilaString pila = new MyPilaString(6);
		
		
		pila.empilar("Numero 1");
		pila.empilar("Numero 2");
		pila.empilar("Numero 3");
		pila.empilar("Numero 4");
		pila.empilar(1);
		pila.desempilar();
		
		pila.mostrar();
		
	}
}
